-- ==========================================
-- TRABAJO PRACTICO - BASE DE DATOS
-- Sistema de gestion de biblioteca UNTREF
-- ==========================================

BEGIN;

-- INSERTAR ESTUDIANTES--
INSERT INTO estudiante (legajo, dni, nombre, email) VALUES
(1001, '40111222', 'Juan Perez', 'juan@gmail.com'),
(1002, '41222333', 'Maria Lopez', 'maria@gmail.com'),
(1003, '42333444', 'Lucas Gomez', 'lucas@gmail.com'),
(1004, '43444555', 'Sofia Martinez', 'sofia@gmail.com'),
(1005, '44555666', 'Pedro Fernandez', 'pedro@gmail.com'),
(1006, '44555777', 'Luisa Suilingui', 'luisa@gmail.com');

-- INSERTAR LIBROS--
INSERT INTO libro (id_libro, titulo, anio_publicacion, categoria) VALUES
(1, 'Cien años de soledad', 1967, 'Novela'),
(2, 'El principito', 1943, 'Literatura infantil'),
(3, 'Rayuela', 1963, 'Novela'),
(4, 'Clean Code', 2008, 'Programacion'),
(5, 'Habitos atomicos', 2018, 'Desarrollo personal'),
(6, 'Sapiens: De animales a dioses', 2014, 'Historia');

--INSERTAR AUTORES--
INSERT INTO autor (id_autor, nombre) VALUES
(1, 'Gabriel Garcia Marquez'),
(2, 'Antoine de Saint-Exupery'),
(3, 'Julio Cortazar'),
(4, 'Robert C. Martin');

--RELACIONAR LIBROS CON AUTORES--
INSERT INTO libro_autor (id_libro, id_autor) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 1),
(1, 3),
(6, 2);

--INSERTAR PRESTAMOS--
INSERT INTO prestamo (id_prestamo, legajo, id_libro, fecha_prestamo, fecha_devolucion_prevista, devuelto) VALUES
(1, 1001, 1, '2026-08-01', '2026-08-15', FALSE),
(2, 1002, 2, '2026-08-03', '2026-08-17', FALSE),
(3, 1003, 3, '2026-08-05', '2026-08-19', FALSE),
(4, 1004, 4, '2026-08-07', '2026-08-21', FALSE),
(5, 1005, 5, '2026-08-09', '2026-08-23', FALSE),
(6, 1001, 2, '2026-08-10', '2026-08-24', FALSE);

COMMIT;

--VER TABLAS--
SELECT * FROM estudiante;
SELECT * FROM libro;
SELECT * FROM autor;
SELECT * FROM libro_autor;
SELECT * FROM prestamo;

-- ==========================================
--  ACTUALIZACIONES (UPDATE)
-- ==========================================

--A Modificar correo electronico del estudiante
SELECT * FROM estudiante WHERE legajo = 1003;
UPDATE estudiante
SET email = 'lucas.gomez@gmail.com'
WHERE legajo = 1003;

SELECT * FROM estudiante WHERE legajo = 1003;

-- Marcar el préstamo número 3 como devuelto
SELECT * FROM prestamo WHERE id_prestamo = 3;

UPDATE prestamo
SET devuelto = TRUE
WHERE id_prestamo = 3;
SELECT * FROM prestamo WHERE id_prestamo = 3;
SELECT * FROM prestamo;


-- ==========================================
-- ELIMINACIONACIONES (DELETE)
-- ==========================================

-- a Eliminar el autor 4
SELECT * FROM autor;

DELETE FROM libro_autor WHERE id_autor = 4;
DELETE FROM autor
WHERE id_autor = 4;

SELECT * FROM autor;

-- ==========================================
-- CONSULTAS EN SQL 
-- ==========================================

--Mostrar todos los estudiantes registrados, indicando legajo, nombre y
--correo electrónico

SELECT legajo, nombre, email
FROM estudiante
ORDER BY legajo;

--Mostrar los libros publicados a partir de X año (año de publicación, elegir
--según los datos cargados), ordenados desde el más reciente al más
--antiguo

SELECT titulo, anio_publicacion
FROM libro
WHERE anio_publicacion >= 2000
ORDER BY anio_publicacion DESC;

-- Mostrar solamente los préstamos que todavía no hayan sido devueltos.
SELECT id_prestamo, legajo, id_libro, fecha_prestamo, fecha_devolucion_prevista
FROM prestamo
WHERE devuelto = FALSE
ORDER BY fecha_prestamo;

--Mostrar los libros pertenecientes a una categoría a elección (elegida entre
--las categorías cargadas previamente)

SELECT id_libro, titulo, anio_publicacion, categoria
FROM libro
WHERE categoria = 'Novela'
ORDER BY titulo;
